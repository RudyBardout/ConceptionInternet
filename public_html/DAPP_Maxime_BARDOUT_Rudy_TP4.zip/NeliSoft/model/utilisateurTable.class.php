<?php

class utilisateurTable
{
  public static function getUserByLoginAndPass($login,$pass)
  {
    $connection = new dbconnection() ;
    $sql = "select * from jabaianb.utilisateur where identifiant='".$login."' and pass='".sha1($pass)."'" ;

    $res = $connection->doQuery( $sql );
    
    if($res === false)
      return false ;

    return $res ;
  }

  public static function getUserById($id)
  {

  }

  public static function getUsers()
  {

  }

  public static function inscription($context)
  {
    $connection = new dbconnection() ;
    $query="Select identifiant from jabaianb.utilisateur where identifiant='".$context->login."';";
    $res = $connection->doQuery( $query );
    if($res === false){
      return false ;
    }
    else if (!empty($res)) {
      return 2;
    }
    else {
      $sql = "INSERT INTO jabaianb.utilisateur('nom','prenom','utilisateur','pass','avatar') VALUES ('".$_POST["nom"]."', '".$_POST["prenom"]."', '".$_POST["pass"]."','".$_POST["avatar"]."';";
        $res = $connection->doQuery( $sql );
    }
  }
}
