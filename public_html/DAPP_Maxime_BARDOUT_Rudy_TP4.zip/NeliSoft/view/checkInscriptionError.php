Erreur lors de l'inscription.
<?php echo $context->erreur; ?>