<html lang="Fr">

<head> 
		<title> Profil </title>
<body>

<ul> <?php foreach( $context->res as $res ): ?>
<li><?php echo $res ?></li> <?php end foreach; ?>
</ul>