<html>
<body>
<a href='inscription.php'> S'inscrire </a>