<?php echo "Erreur dans l'identification";
echo $context->erreur;
?>